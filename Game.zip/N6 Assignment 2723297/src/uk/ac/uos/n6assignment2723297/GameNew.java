package uk.ac.uos.n6assignment2723297;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.lang.reflect.Array;
import java.util.ArrayList;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.swing.ImageIcon;

import game2D.*;


public class GameNew extends GameCore {

	/** Screen Width */
	static int screenWidth = 1024;

	/** Screen Height */
	static int screenHeight = 576;

	/** Player Sprite */
	Sprite player;
	
	Sprite turtle;
	
	Sprite apple;
	
	Sprite banana;
	
	Sprite pig;
	
	Sprite bat;
	
	Sprite rock;
	
	Sprite tresure;
	
	
	/** Animation for right Idle */
	Animation idlerightplayer;

	/** Animation for right Idle */
	Animation idleleftplayer;

	/** Animation for running right */
	Animation runrightplayer;

	/** Animation for running left */
	Animation runleftplayer;

	/** Animation Attack rigth */
	Animation attackrightplayer;

	/** Animation Attack left */
	Animation attackleftplayer;

    Animation hitplayerleft;
    
    Animation hitplayerright;
    
    Animation ragerunleft;

	Animation ragerunright;

	Animation rageidleleft;

	Animation rageidleright;
	
	Animation turtleidle;
	
	Animation turtlespikeout;
	
	Animation turtlespikein;
	
	Animation turtleidlespike;
	
	Animation pigrunleft;
	
	Animation pigrunright;
	
	Animation pigidleleft;
	
	Animation pigidleright;
	
	Animation applean;
	
	Animation bananaan;
	
	Animation Cave;
	
	Animation batflyingleft;
	
	Animation batflyingright;
	
	Animation rockidleleft;
	
	Animation rockidleright;
	
	Animation rockrunleft;
	
	Animation rockrunright;
	
	Animation tresurechest;
	
	Sound background;
	
	Sound jumping;
	
	Sound hit;
	
	Sound food;
	
	Sound ragesound;
	
	Sound enemyhit;
	
	SoundFilterPlay foodcave;
	
	/** Tile map */
	TileMap tmap_level1 = new TileMap();
	
	TileMap tmap_level2 = new TileMap();

	/** Boolean for left position */
	Boolean left = false;

	/** Boolean for right position */
	Boolean right = false;

	/** Boolean for idle */
	Boolean idle = true;

	/** Boolean jump */
	Boolean jump = false;

	/** Boolean attack */
	 Boolean rage = false;

	Boolean reset = false;

	/** X Velocity */
     float xVelocity = 0.2f;

	float gravity = 0.0009f;

	/** Life */
	int life = 5;
	
	int score=0;
	
	long startRage;
	
	Image pine;
	
	Image mountain;
	
	Image sky;
	
	Image heart;
	
	Image cave_bck1;
	
	Image cave_bck2;
	
	Image cave_bck3;
	
	Image cave_bck4;
	
	Sprite cave;
	
	int level=1;
	
	ArrayList<Sprite> turtles;
	 
	ArrayList<Sprite> pigs;
	
	ArrayList<Sprite> apples;
	
	ArrayList<Sprite> bananas;
	
	ArrayList<Sprite> bats;
	
	ArrayList<Sprite> rocks;

	SoundFilterPlay hitcave;
	/**
	 * The obligatory main method that creates an instance of our class and starts
	 * it running
	 * 
	 * @param args The list of parameters this program might use (ignored)
	 */
	public static void main(String[] args) {
		GameNew gct = new GameNew();
		gct.init();
		// Start in windowed mode with the given screen height and width
		gct.run(false, screenWidth, screenHeight);
	}

	public void init() {
		/** Temporary reference for sprite */
		Sprite s;
        
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//background = new Sound("sounds/backgroundmusic.wav");
	   // background.start();
		// Load the tile map and print it out so we can check it is valid
		tmap_level1.loadMap("maps", "map-level1.txt");
		
		tmap_level2.loadMap("maps","map-level2.txt");
		
		// Initialise the sprite and animation
		loadAnimation();
        
		turtles=new ArrayList<Sprite>();
		 
		pigs=new ArrayList<Sprite>();
		
		bananas=new ArrayList<Sprite>();
		
		apples=new ArrayList<Sprite>();
		
		bats=new ArrayList<Sprite>();
		
		rocks=new ArrayList<Sprite>();
		
		player = new Sprite(idlerightplayer);
		
		cave=new Sprite(Cave);
		
		bat=new Sprite(batflyingleft);
		
		rock=new Sprite(rockidleleft);
		
		tresure=new Sprite(tresurechest);
		
		sky=new ImageIcon("images/sky_cloud.png").getImage();
			
		mountain=new ImageIcon("images/mountain2.png").getImage();
		
		pine=new ImageIcon("images/pine1.png").getImage();
		
		heart=new ImageIcon("images/pixel-heart.png").getImage();
		
		cave_bck1=new ImageIcon("images/background1.png").getImage();
		
		cave_bck2=new ImageIcon("images/background2.png").getImage();
		
		cave_bck3=new ImageIcon("images/background3.png").getImage();
		
		cave_bck4=new ImageIcon("images/background4a.png").getImage();
		
		setSize(screenWidth, screenHeight);
		setVisible(true);

		initialiseGame();
		
		
	}

	public void initialiseGame() {

		
		if(level==1)
		{
			setSpriteLevel1();
			cave.setX(3000);
		    cave.setY(120);
		    cave.show();
		    player.setX(0);
		    player.setY(500);
		    player.setVelocityX(0);
		    player.setVelocityY(0);
		    player.show();
		
		}
		else if(level==2)
		{
			setSpriteLevel2();
			player.setX(0);
			player.setY(800);
			player.setVelocityX(0);
			player.setVelocityY(0);
			player.show();
			tresure.setX(0);
			tresure.setY(0);
			tresure.show();
		}
		
		
		
	}
	
	public void setSpriteLevel1()
	{
		System.out.println("SPRITES");
		for(int i=0;i<7;i++)
		{
			turtle = new Sprite(turtleidle);
			if(i==0)
			{
				turtle.setX(400);
			}
			else
			{
				turtle.setX(turtles.get(i-1).getX()+400);
			}
			turtle.setY(400);
			turtle.setVelocityX(0);
			turtle.setVelocityY(0);
			turtles.add(turtle);
			turtles.get(i).show();
			
		}
		for(int i=0;i<4;i++)
		{
			pig=new Sprite(pigidleleft);
			if(i==0)
			{
				pig.setX(500);
			}
			else
			{
				pig.setX(pigs.get(i-1).getX()+800);
			}
			pig.setY(400);
			pig.setVelocityX(0);
			pig.setVelocityY(0);
			pigs.add(pig);
			pigs.get(i).show();
			
		}
		for(int i=0;i<2;i++)
		{
			apple=new Sprite(applean);
			if(i==0)
			{
				apple.setX(100);
			}
			else
			{
				apple.setX(apples.get(i-1).getX()+100);
			}
			apple.setY(400);
			apple.setVelocityX(0);
			apple.setVelocityY(0);
			apples.add(apple);
			apples.get(i).show();
			
		}
		for(int i=0;i<=5;i++)
		{
			banana=new Sprite(bananaan);
			if(i==0)
			{
				banana.setX(300);
			}
			else
			{
				banana.setX(bananas.get(i-1).getX()+300);
			}
			banana.setY(500);
			banana.setVelocityX(0);
			banana.setVelocityY(0);
			bananas.add(banana);
			bananas.get(i).show();
			
		}
	}
	
	public void setSpriteLevel2()
	{
		System.out.println("SPRITES");
		for(int i=0;i<4;i++)
		{
			bat= new Sprite(batflyingleft);
			if(i==0)
			{
				bat.setX(100);
				bat.setY(225);
			}
			else
			{
				bat.setY(bats.get(i-1).getY()+175);
				bat.setX(bats.get(i-1).getX()+20);
			}
			
		    bat.setVelocityX(-0.1f);
			bat.setVelocityY(0);
			bats.add(bat);
			bats.get(i).show();
			
		}
		for(int i=0;i<2;i++)
		{
			rock=new Sprite(rockidleleft);
			if(i==0)
			{
				rock.setY(310);
				rock.setX(100);
			}
			else
			{
				rock.setY(rocks.get(i-1).getY()+220);
				rock.setX(rocks.get(i-1).getX()+50);
			}
			rock.setVelocityX(0);
			rock.setVelocityY(0);
			rocks.add(rock);
			rocks.get(i).show();
			
		}
		for(int i=0;i<2;i++)
		{
			apple=new Sprite(applean);
			if(i==0)
			{
				apple.setY(100);
			}
			else
			{
				apple.setY(apples.get(i-1).getY()+200);
			}
			apple.setX(400);
			apple.setVelocityX(0);
			apple.setVelocityY(0);
			apples.add(apple);
			apples.get(i).show();
			
		}
		for(int i=0;i<3;i++)
		{
			banana=new Sprite(bananaan);
			if(i==0)
			{
				banana.setY(400);
			}
			else
			{
				banana.setY(bananas.get(i-1).getY()+310);
			}
			banana.setX(300);
			banana.setVelocityX(0);
			banana.setVelocityY(0);
			bananas.add(banana);
			bananas.get(i).show();
			
		}
	}

	public void loadAnimation() {
		// Initialise the animation for the player
		idlerightplayer = new Animation();
		idlerightplayer.loadAnimationFromSheet("images/idle-right.png", 11, 1, 300);
        
		idleleftplayer=new Animation();
		idleleftplayer.loadAnimationFromSheetOpposite("images/idle-left.png", 11, 1, 300);
	
		runrightplayer = new Animation();
		runrightplayer.loadAnimationFromSheet("images/run-right.png", 12, 1, 60);
        
		runleftplayer = new Animation();
		runleftplayer.loadAnimationFromSheetOpposite("images/run-left.png", 12, 1, 60);
		
	
		hitplayerleft = new Animation();
		hitplayerleft.loadAnimationFromSheetOpposite("images/hit-left", 7, 1, 90);
		
		hitplayerright = new Animation();
		hitplayerright.loadAnimationFromSheet("images/hit-right", 7, 1, 90);
		
		ragerunleft=new Animation();
		ragerunleft.loadAnimationFromSheetOpposite("images/rage-run-left.png",12,1,60);
		
		ragerunright=new Animation();
		ragerunright.loadAnimationFromSheet("images/rage-run-right.png",12,1,60);
		
		rageidleleft=new Animation();
		rageidleleft.loadAnimationFromSheetOpposite("images/rage-idle-left.png",11,1,60);
		
		rageidleright=new Animation();
		rageidleright.loadAnimationFromSheet("images/rage-idle-right.png",11,1,60);

		
		
		
		turtleidle=new Animation();
		turtleidle.loadAnimationFromSheet("images/turtleidle.png", 14, 1, 100);
		
		turtleidlespike=new Animation();
		turtleidlespike.loadAnimationFromSheet("images/turtleidlespike.png", 14, 1, 100);
		
		turtlespikein=new Animation();
		turtlespikein.loadAnimationFromSheet("images/turtlespikein.png", 8, 1, 100);
		
		turtlespikeout=new Animation();
		turtlespikeout.loadAnimationFromSheet("images/turtlespikeout.png", 8, 1, 100);
		
		
		pigidleleft=new Animation();
		pigidleleft.loadAnimationFromSheet("images/pig-idle-left.png", 9, 1, 100);
		
		pigidleright=new Animation();
		pigidleright.loadAnimationFromSheetOpposite("images/pig-idle-right.png", 9, 1, 100);
		
		pigrunleft=new Animation();
		pigrunleft.loadAnimationFromSheet("images/pig-run-left.png", 12, 1, 100);
		
		pigrunright=new Animation();
		pigrunright.loadAnimationFromSheetOpposite("images/pig-run-right.png", 12, 1, 100);
		
		applean=new Animation();
		applean.loadAnimationFromSheet("images/Apple.png", 17, 1, 100);
		
		bananaan=new Animation();
		bananaan.loadAnimationFromSheet("images/Bananas.png", 17, 1, 100);
		
		Cave=new Animation();
		Cave.loadAnimationFromSheet("images/cave-pixel.png",1,1,100);
		
		batflyingleft=new Animation();
		batflyingleft.loadAnimationFromSheet("images/bat-flying-left.png", 7, 1, 100);
		
		batflyingright=new Animation();
		batflyingright.loadAnimationFromSheetOpposite("images/bat-flying-right.png", 7, 1, 100);
		
		rockidleleft=new Animation();
		rockidleleft.loadAnimationFromSheet("images/rock-idle-left.png", 14, 1, 100);
		
		rockidleright=new Animation();
		rockidleright.loadAnimationFromSheetOpposite("images/rock-idle-left.png", 14, 1, 100);
		
		rockrunleft=new Animation();
		rockrunleft.loadAnimationFromSheet("images/rock-run-left.png", 14, 1, 100);
		
		rockrunright=new Animation();
		rockrunright.loadAnimationFromSheetOpposite("images/rock-run-right.png", 14, 1, 100);
		
		tresurechest=new Animation();
		tresurechest.loadAnimationFromSheet("images/treasure.png", 1, 1, 100);
	}

	
	public void draw(Graphics2D g) {

		// Drawing the objects
		int xo = 0;
		int yo = 0;
		
		if (level==1)
		{
			// Apply offsets to player and draw
			if ((int) player.getX() >= getWidth() / 2) {
				xo = -(int) player.getX() + getWidth() / 2;
			}
			g.drawImage(sky, 0, 0,screenWidth*2,screenHeight, null, null);
		    g.drawImage(mountain, 0, 0, screenWidth*2,screenHeight, null, null);
			drawSpriteLevel1(g,xo,yo);
			tmap_level1.draw(g, xo, yo);
			cave.setOffsets(xo, yo);
		    cave.draw(g);
		}
        
		else if(level==2)
		{
			if ((int) player.getY() >= getWidth() / 2) {
				yo = -(int) player.getY() + getWidth() / 2;
			}
			g.drawImage(cave_bck1, 0, 0,screenWidth,screenHeight*2, null, null);
		    g.drawImage(cave_bck2, 0, 0, screenWidth,screenHeight*2, null, null);
		    g.drawImage(cave_bck3, 0, 0,screenWidth,screenHeight*2, null, null);
		    g.drawImage(cave_bck4, 0, 0, screenWidth,screenHeight*2, null, null);
		    tmap_level2.draw(g, xo, yo);
		    drawSpriteLevel2(g,xo,yo);
		    tresure.setOffsets(xo, yo);
		    tresure.draw(g);
		}
		
		g.drawImage(heart,getWidth() - 80, 35,25,25,null,null);
		String msg = String.format("X "+life);
		g.setColor(Color.white);
		g.drawString(msg, getWidth() - 50, 52);
		
		String scoremsg = String.format("Score: "+score);
		g.setColor(Color.white);
		g.drawString(scoremsg, getWidth() - 140, 50);
		// Apply offsets to tile map and draw it
		player.setOffsets(xo, yo);
		player.draw(g);
		
		

	}
	
	public void drawSpriteLevel1(Graphics2D g,int x, int y)
	{
		for(Sprite turtle:turtles)
		{
			turtle.setOffsets(x,y);
			turtle.draw(g);
			turtle.drawBoundingBox(g);
		}
		for(Sprite pig:pigs)
		{
			pig.setOffsets(x,y);
			pig.draw(g);
			
		}
		for(Sprite apple:apples)
		{
			apple.setOffsets(x,y);
			apple.draw(g);
			
		}
		for(Sprite banana:bananas)
		{
			banana.setOffsets(x, y);
			banana.draw(g);
		}
	}
	
	public void drawSpriteLevel2(Graphics2D g,int x, int y)
	{
		for(Sprite bat:bats)
		{
			bat.setOffsets(x,y);
			bat.draw(g);
		}
		
		for(Sprite rock:rocks)
		{
			rock.setOffsets(x,y);
			rock.draw(g);
			
		}
		for(Sprite apple:apples)
		{
			apple.setOffsets(x,y);
			apple.draw(g);
			
		}
		for(Sprite banana:bananas)
		{
			banana.setOffsets(x, y);
			banana.draw(g);
		}
	}

	public void update(long elapsed) {
        
		if(level==1)
		{  
			if(!checkTileCollision(player, tmap_level1))
			{
				player.setVelocityY(player.getVelocityY() + (gravity * elapsed));
			}
			canJump(player,tmap_level1);
			getSpriteCollisionsLevel1(elapsed);
			cave.update(elapsed);
		    cave(cave);
		}
		else if(level==2)
		{
			if(!checkTileCollision(player, tmap_level2))
			{
				player.setVelocityY(player.getVelocityY() + (gravity * elapsed));
			}
			canJump(player,tmap_level2);
			getSpriteCollisionsLevel2(elapsed);
			tresure.update(elapsed);
		}
		player.update(elapsed);
		
	
		
		
		if(rage && (System.currentTimeMillis()-startRage)>=10000)
		{
			rage=false;
			if(left)
			{
				player.setAnimation(idleleftplayer);
			}
			if(right)
			{
				player.setAnimation(idlerightplayer);
			}
		}
	
		if(life<=0)
		{
			if(score>=2)
			{
				score=score-2;
			}
			else if(score<=1)
			{
				score=0;
			}
			resetGame();
			
		}
		
		/*if(background.getFinished()==true)
		{
			background = new Sound("sounds/backgroundmusic.wav");
		    background.start();
		}*/
	}
	public void resetGame()
	{
		life=5;
		rage=false;

		if(level==1)
		{
		
		player.setX(0);
		player.setY(500);
		player.setVelocityX(0);
		player.setVelocityY(0);
		player.show();
		
		}
		else if(level==2)
		{
			
			player.setX(0);
			player.setY(800);
			player.setVelocityX(0);
			player.setVelocityY(0);
			player.show();
		}
	}
	public void getSpriteCollisionsLevel1(long elapsed)
	{
		for(Sprite turtle:turtles)
		{
			turtle.update(elapsed);
			if(!checkTileCollision(turtle,tmap_level1))
			{
				turtle.setVelocityY(turtle.getVelocityY() + (gravity * elapsed));
			}
			turtleInteraction(turtle);
			
			
		}
		for(Sprite pig:pigs)
		{	
			  pig.update(elapsed);
			if(!checkTileCollision(pig,tmap_level1))
			{
				pig.setVelocityY(pig.getVelocityY() + (gravity * elapsed));
			}
			pigInteraction(pig);
			for(Sprite turtle:turtles)
			{
				enemyCollisionsEach(pig,turtle);
			}
		   
		}
		for(Sprite apple:apples)
		{
			apple.update(elapsed);
			if(!checkTileCollision(apple,tmap_level1))
			{
				apple.setVelocityY(apple.getVelocityY() + (gravity * elapsed));
			}
			powerupCollision(apple);
			
			
		}
		for(Sprite banana:bananas)
		{
			banana.update(elapsed);
			if(!checkTileCollision(banana,tmap_level1))
			{
				banana.setVelocityY(banana.getVelocityY() + (gravity * elapsed));
			}
			
			powerupCollision(banana);
			
			
		}
	}
	
	public void getSpriteCollisionsLevel2(long elapsed)
	{
		for(Sprite bat:bats)
		{
			bat.update(elapsed);
			checkTileCollisionBat(bat, tmap_level2);
			batInteraction(bat);
			for(Sprite rock:rocks)
			{
				batRockCollision(bat,rock);
			}
			
			
		}
		for(Sprite rock:rocks)
		{
			rock.update(elapsed);
			if(!checkTileCollision(rock, tmap_level2))
			{
			rock.setVelocityY(rock.getVelocityY() + (gravity * elapsed));	
			}			
			rockInteraction(rock);
			for(Sprite bat:bats)
			{
				batRockCollision(bat,rock);
			}
			
		}
		for(Sprite apple:apples)
		{
			apple.update(elapsed);
			if(!checkTileCollision(apple,tmap_level1))
			{
				apple.setVelocityY(apple.getVelocityY() + (gravity * elapsed));
			}
			powerupCollision(apple);
			
			
		}
		for(Sprite banana:bananas)
		{
			banana.update(elapsed);
			if(!checkTileCollision(banana,tmap_level1))
			{
				banana.setVelocityY(banana.getVelocityY() + (gravity * elapsed));
			}
			
			powerupCollision(banana);
		}

	}
	
	public void keyPressed(KeyEvent e) {

		int key = e.getKeyCode();

		switch (key) {

		case KeyEvent.VK_ESCAPE:
			stop();
			break;

		case KeyEvent.VK_LEFT:
			left=true;
			right=false;
			player.setVelocityX(-xVelocity);
			if(!rage) player.setAnimation(runleftplayer);
			if(rage) player.setAnimation(ragerunleft);
			break;

		case KeyEvent.VK_RIGHT:
			right=true;
			left=false;
			player.setVelocityX(xVelocity);
			if(!rage) player.setAnimation(runrightplayer);
			if(rage) player.setAnimation(ragerunright);
			
			break;
			
		case KeyEvent.VK_UP:
			
			
			 if(jump)
	           {
				jumping=new Sound("sounds/jump.wav");
	        	jumping.start();
	        	player.setVelocityY(-0.5f);
	        	System.out.println("press");
	            jump=false;
	           
			  }
	
			break;

		case KeyEvent.VK_C:
			rage=true;
			startRage=System.currentTimeMillis();
			break;
		default:
			break;
		}
	}
     
	/**
	 * Key Released method
	 */
	
	public void keyReleased(KeyEvent e) {

		int key = e.getKeyCode();

		switch (key) {
		case KeyEvent.VK_ESCAPE:
			stop();
			break;

		case KeyEvent.VK_LEFT:
			player.setVelocityX(0);
			if(!rage) player.setAnimation(idleleftplayer);
			if(rage) player.setAnimation(rageidleleft);
			break;

		case KeyEvent.VK_RIGHT:
			player.setVelocityX(0);
			if(!rage) player.setAnimation(idlerightplayer);
			if(rage) player.setAnimation(rageidleright);
			break;
		
			
		case KeyEvent.VK_UP: 
			if(!rage) {
			if(right) player.setAnimation(idlerightplayer);
			if(left) player.setAnimation(idleleftplayer);	
			}
			if(rage)
			{
			if(right) player.setAnimation(rageidleright);
			if(left) player.setAnimation(rageidleleft);
			}
			break;

		default:
			break;
		}
	}
	
	public void pigMovement(Sprite s)
	{
		if(player.getX()>s.getX())
		{
			s.setAnimation(pigidleright);
			if(0<=(player.getX()-s.getX())&&(player.getX()-s.getX())<=200)
			{
				s.setAnimation(pigrunright);
				s.setVelocityX(0.04f);
			}
		}
		else if(player.getX()<s.getX())
		{
			s.setAnimation(pigidleleft);
			if(0<=(s.getX()-player.getX()) && (s.getX()-player.getX())<=200)
			{
				s.setAnimation(pigrunleft);
				s.setVelocityX(-0.04f);
			}
		}
	}
	public void  cave(Sprite s)
	{
		if(boundingBoxCollision(player,s))
		{
			level++;
			initialiseGame();
		}
		
	}
	public void pigInteraction(Sprite s)
	{
		pigMovement(s);
		enemyCollision(s);
	}
    
	public void enemyCollisionsEach(Sprite s,Sprite v)
	{
		if(boundingBoxCollision(s,v) && v.isVisible())
		{
			s.stop();
			s.setVelocityX(0);
		}
	}
	public void powerupCollision(Sprite s)
	{	
		
		if(s.getX()-20<=player.getX() && player.getX()<=s.getX()+20 && s.getY()-20<=player.getY() && player.getY()<=s.getY()+20 && s.isVisible())
		{
			if(level==1)
			{
				food=new Sound("sounds/crunch.wav");
		      	food.start();
			}
			else if(level==2)
			{
				foodcave=new SoundFilterPlay("sounds/crunch.wav");
				foodcave.start();
				
			}
			
			if(s.getAnimation()==bananaan)
			{
				
				ragesound=new Sound("sounds/rage.wav");
				ragesound.start();
				rage=true;
				startRage=System.currentTimeMillis();
				s.hide();
				
				
			}
			else if(s.getAnimation()==applean)
			{
				
		        life=life+1;
		        s.hide();
			}
			
		}
		
	}
	public void turtleInteraction(Sprite s)
	{
		
		turtleMovement(s);
		enemyCollision(s);
		
	}
	public void turtleMovement(Sprite s)
	{
		if(0<=(s.getX()-player.getX()) && (s.getX()-player.getX())<=100 || 0<=(player.getX()-s.getX())&&(player.getX()-s.getX())<=100)
		   {
			      s.setAnimation(turtlespikeout);
			      s.setAnimation(turtleidlespike);
			    
		   }
		
		   else if(s.getAnimation()==turtleidlespike)
		   {
			   s.setAnimation(turtlespikein);
			   s.setAnimation(turtleidle);
		   }
		
	}
	public void batInteraction(Sprite s)
	{
		batMovement(s);
		enemyCollision(s);
	}
	public void batMovement(Sprite s)
	{
		if(s.getX()>=screenWidth-100)
		{
			s.setVelocityX(-0.1f);
			s.setAnimation(batflyingleft);
		}
		else if(s.getX()<=0)
		{
	
			s.setVelocityX(+0.1f);
			s.setAnimation(batflyingright);
		}
	}public void rockInteraction(Sprite s)
	{
		rockMovement(s);
		enemyCollision(s);
	}
	
	public void rockMovement(Sprite s)
	{
		if(player.getY()>=s.getY()-20)
		{
			if(player.getX()>s.getX())
			{
				s.setAnimation(rockidleright);
				if(0<=(player.getX()-s.getX())&&(player.getX()-s.getX())<=100)
				{
					s.setAnimation(rockrunright);
					s.setVelocityX(0.04f);
				}
			}
			else if(player.getX()<s.getX())
			{
				s.setAnimation(rockidleleft);
				if(0<=(s.getX()-player.getX()) && (s.getX()-player.getX())<=100)
				{
					s.setAnimation(rockrunleft);
					s.setVelocityX(-0.04f);
				}
			}
		}
		
	}
	public void batRockCollision(Sprite b,Sprite r)
	{
		if(boundingBoxCollision(b,r) && (b.isVisible()|| r.isVisible()))
		{
			r.stop();
			r.setVelocityX(0);
			if(b.getX()>r.getX())
			{
				b.setAnimation(batflyingright);
				b.setVelocityX(+0.1f);
			}
			else if(b.getX()<r.getX())
			{
				b.setAnimation(batflyingleft);
				b.setVelocityX(-0.1f);
			}
		}
	}
	public void  enemyCollision(Sprite s)
	{
         
		if(boundingBoxCollision(s,player) && s.isVisible())
		{
			if(!rage)
			{
				if(level==1) {
					hit= new Sound("sounds/hit.wav");
				    hit.start();
				}
				else if(level==2) {
				
					hitcave=new SoundFilterPlay("sounds/hit.wav");
					hitcave.start();
					
				}
				
				life=life-1;
				if(right)
					{
					player.setAnimation(hitplayerright);
					player.setX(player.getX()-50);
					player.setAnimation(idlerightplayer);
					}
				if(left) 
			       {
					player.setAnimation(hitplayerleft);
					player.setX(player.getX()+50);
					player.setAnimation(idleleftplayer);
			       }
				
			}
			
			if(rage)
			{
				s.hide();
				enemyhit=new Sound("sounds/enemy-hit.wav");
				enemyhit.start();
				score++;
			}
		}
		
	}
	public boolean canJump(Sprite s,TileMap tmap)
	{
		
		float sx = s.getX();
		float sy = s.getY();
		
		float tileWidth = tmap.getTileWidth();
		float tileHeight = tmap.getTileHeight();
		
		int xtile = (int) ((sx+(s.getWidth()/2)) / tileWidth);
		int ytile = (int) ((sy+s.getHeight()+4) / tileHeight);
		
		char ch = tmap.getTileChar(xtile, ytile);
		System.out.println(ch);
		if(ch !='.')
		{
		    System.out.println("True");
		    jump=true;
			return jump;
		}
		else 
		{
			jump=false;
			return jump;
		}
		
	}
	
	public  boolean checkTileCollision(Sprite s, TileMap tmap) {
		
	    boolean colliding=false;
		// Take a note of a sprite's current position
		float sx = s.getX();
		float sy = s.getY();
 
		// Find out how wide and how tall a tile is
		float tileWidth = tmap.getTileWidth();
		float tileHeight = tmap.getTileHeight();

		// Divide the sprites x coordinate by the width of a tile, to get
		// the number of tiles across the x axis that the sprite is positioned at
		int xtile = (int) (sx / tileWidth);

		// The same applies to the y coordinate
		int ytile = (int) (sy / tileHeight);

		// What tile character is at the top left of the sprite s?
		char ch = tmap.getTileChar(xtile, ytile);

		if (ch == 'g') // If it's not a dot (empty space), handle it
		{
			// Here we just stop the sprite.
			s.stop();
			s.setX(s.getX() + xVelocity);
            
			// You should move the sprite to a position that is not colliding
		}

		// We need to consider the other corners of the sprite
		// The above looked at the top left position, let's look at the bottom left.
		xtile = (int) (sx / tileWidth);
		ytile = (int) ((sy + s.getHeight()) / tileHeight);
		ch = tmap.getTileChar(xtile, ytile);
		// If it's not empty space
		if (ch == 'g') {
			// Let's make the sprite bounce
			s.stop();
			s.setY(sy-4);
			colliding=true;

		}
		// Collision for the corner of the top right
		xtile = (int) ((sx + s.getWidth()) / tileWidth);
		ytile = (int) ((sy + s.getHeight()) / tileHeight);
		ch = tmap.getTileChar(xtile, ytile);
		// If it's not empty space
		if (ch == 'g') {
			// Let's make the sprite bounce
			s.stop();
			//s.setX(s.getX() - xVelocity);
			s.setY(sy-4);
			colliding=true;

		}

		// Collision for the corner of the bottom right
		xtile = (int) ((sx + s.getWidth()) / tileWidth);
		ytile = (int) (sy / tileHeight);
		ch = tmap.getTileChar(xtile, ytile);
		// If it's not empty space
		if (ch == 'g') {
			// Let's make the sprite bounce
			s.stop();
			//s.setX(s.getX() - xVelocity);

		}
		
		if(s.getX()<=0 )
		{
			s.stop();
			s.setX(s.getX()+10);
		}
		if(s.getX()>=screenWidth-5 && level==2)
		{
			s.stop();
			s.setX(s.getX()-20);
		}
		xtile = (int) (((sx + s.getWidth())/2) / tileWidth);
		ytile = (int) (sy+s.getHeight() / tileHeight);
		ch = tmap.getTileChar(xtile, ytile);
		// If it's not empty space
		if (s.getY()>=screenHeight && level==1) {
			 s.stop();
		if(s.equals(player)) {
		  life=0;
		  }
		else {
			  s.hide();
		  }
		  
		
		 
		  }
		return colliding;
	}
	
	public void checkTileCollisionBat(Sprite s, TileMap tmap) {
		// Take a note of a sprite's current position
		float sx = s.getX();
		float sy = s.getY();

		// Find out how wide and how tall a tile is
		float tileWidth = tmap.getTileWidth();
		float tileHeight = tmap.getTileHeight();

		// Divide the sprites x coordinate by the width of a tile, to get
		// the number of tiles across the x axis that the sprite is positioned at
		int xtile = (int) (sx / tileWidth);

		// The same applies to the y coordinate
		int ytile = (int) (sy / tileHeight);

		// What tile character is at the top left of the sprite s?
		char ch = tmap.getTileChar(xtile, ytile);

		if (ch != '.') // If it's not a dot (empty space), handle it
		{
			// Here we just stop the sprite.
			s.setVelocityX(-s.getVelocityX());
            s.setAnimation(batflyingright);
			// You should move the sprite to a position that is not colliding
		}

		// We need to consider the other corners of the sprite
		// The above looked at the top left position, let's look at the bottom left.
		xtile = (int) (sx / tileWidth);
		ytile = (int) ((sy + s.getHeight()) / tileHeight);
		ch = tmap.getTileChar(xtile, ytile);
		// If it's not empty space
		if (ch != '.') {
			// Let's make the sprite bounce
			s.setVelocityX(-s.getVelocityX());
			s.setY(sy-3);
		    s.setAnimation(batflyingright);

		}
		// Collision for the corner of the top right
		xtile = (int) ((sx + s.getWidth()) / tileWidth);
		ytile = (int) ((sy + s.getHeight()) / tileHeight);
		ch = tmap.getTileChar(xtile, ytile);
		// If it's not empty space
		if (ch != '.') {
			// Let's make the sprite bounce
			s.setVelocityX(-s.getVelocityX());
			 s.setY(sy-3);
			 s.setAnimation(batflyingleft);

		}

		// Collision for the corner of the bottom right
		xtile = (int) ((sx + s.getWidth()) / tileWidth);
		ytile = (int) (sy / tileHeight);
		ch = tmap.getTileChar(xtile, ytile);
		// If it's not empty space
		if (ch != '.') {
			// Let's make the sprite bounce
			s.setVelocityX(-s.getVelocityX());
			s.setAnimation(batflyingleft);
			
		}
		

	}


	public boolean boundingBoxCollision(Sprite s1, Sprite s2) {
		return ((s1.getX() + s1.getImage().getWidth(null) > s2.getX())
				&& (s1.getX() < (s2.getX() + s2.getImage().getWidth(null)))
				&& ((s1.getY() + s1.getImage().getHeight(null) > s2.getY())
						&& (s1.getY() < s2.getY() + s2.getImage().getHeight(null))));
	}

}
